"""Presenter helper modules."""

from .split_manager import SplitManager

__all__ = ['SplitManager']